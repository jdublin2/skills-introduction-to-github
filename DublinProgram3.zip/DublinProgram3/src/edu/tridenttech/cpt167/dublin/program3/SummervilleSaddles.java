//NAME: JAMES DUBLIN II
//COURSE: CPT 167
//PURPOSE: SELL & CALCULATE TIX SALES
//STARTDATE: 2/3/25
package edu.tridenttech.cpt167.dublin.program3;
//IMPORT SCANNER 
import java.util.Scanner; 

public class SummervilleSaddles {

	public static void main(String[] args) {
//DECLARATIONS AND INITIALIZATIONS
		final char selection_A = 'A';
		final char selection_B = 'B';
		final char selection_C = 'C';
		final char selection_D = 'D';
		final double price_A = 50.00;
		final double price_B = 75.00; 
		final double price_C = 125.00; 
		final String tixType1 = "One-hour ride";
		final String tixType2 = "Two-hour ride";
		final String tixType3 = "Half-day ride";
		final String quit = "Quit";
		
		char selection = ' '; 
		int tix = 1;
		String type = null;
		double price = 0;
		int total = 0;
		double orderPrice = 0; 
		
//SCANNER STATEMENT
Scanner input = new Scanner(System.in);

//WELCOME BANNER
System.out.println("Welcome to Summerville Saddles!" 
+ "\nTake a look at our Menu");
System.out.println("");
//MAIN LOOP
while (selection != selection_D)
{
//MENU-INPUTS
//INPUTS-MENU
System.out.println("Ticket Menu");
System.out.printf("%1s) %-20s $%.2f\n" , selection_A, tixType1, price_A);
System.out.printf("%1s) %-20s $%.2f\n" , selection_B, tixType2, price_B);
System.out.printf("%1s) %-20s $%.2f\n" , selection_C, tixType3, price_C);
System.out.printf("%1s) %-20s" , selection_D, quit);
System.out.println("");
System.out.println("Please select your ticket type:");
selection = input.nextLine().toUpperCase().charAt(0);

//VALIDATE INPUT
while (selection != 'A' && selection != 'B' && selection != 'C' && selection != 'D')
	{
		System.out.println("The choice you entered is invalid. Please make a valid selection");
		System.out.println("Please select your ticket type:");
		selection = input.nextLine().toUpperCase().charAt(0);
	}
	
	//SELECTION 
	if (selection != selection_D)
	{
		if (selection == selection_A)
	{
			type = tixType1; 
			price = price_A;
	}
		else if (selection == selection_B)
		{
			type = tixType2;
			price = price_B;
		}
		else if (selection == selection_C)
		{
			type = tixType3;
			price = price_C;
		}
	//QUANTITY INPUT	
	System.out.println("How many tickets would you like to buy?");
	tix = input.nextInt();
	input.nextLine();
	
	//VALIDATE INPUT
	while (tix <= 0)
	{
		System.out.println("The quantity entered is invalid. Please enter a valid quantity.");
		System.out.println("How many tickets would you like to buy?");
		tix = input.nextInt(); 
		input.nextLine();
	}
	//PROCESS
	orderPrice = price * tix;
	total++; 
	 
	//DISPLAY OUTPUT
	System.out.println("Purchase Summary");
	System.out.printf("%-20s %5s\n" , "Type:", type); 
	System.out.printf("%-20s %5d\n" , "Quantity:", tix);
	System.out.printf("%-20s $%5.2f\n" , "Unit Price:", price);
	System.out.printf("%-20s $%5.2f\n" , "Total:", orderPrice);
	System.out.println("");
	}
}
while (total>0)
{
System.out.println("Total Purchases: " + total);
System.out.println("Thank you for choosing Summerville Saddles!");
input.nextLine();
}
System.out.println("Thank you for choosing Summerville Saddles!");
	}

}
