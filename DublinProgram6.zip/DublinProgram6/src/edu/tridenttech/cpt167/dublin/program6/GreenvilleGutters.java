package edu.tridenttech.cpt167.dublin.program6;


public class GreenvilleGutters {

    private final static int NUM_MONTHS = 12;
    private final static double SATISFACTORY_LIMIT = 1000.00;
    private final static double DEFICIENT_LIMIT = 2000.00;
    private final static double BONUS_COMMISSION = 5/100.0;
    private final static char BONUS_MONTH = 'B';
    private final static char SATISFACTORY_MONTH = 'S';
    private final static char DEFICIENT_MONTH = 'N';
    private final static char UNSATISFACTORY_MONTH = 'U';
    
    public static void main(String[] args) {

        //-----------------------------------------------------------
        // You may change the values in these two arrays for testing
        //-----------------------------------------------------------
        double[] testTargetSales = 
        	{
                20_000.00,
                20_000.00,
                20_000.00,
                22_000.00,
                22_000.00,
                22_000.00,
                25_000.00,
                25_000.00,
                25_000.00,
                23_000.00,
                23_000.00,
                23_000.00
                };

        double[] testActualSales = 
        	{
                20_000.00,
                20_100.00,
                23_500.00,
                23_000.00,
                21_030.00,
                23_000.00,
                21_000.00,
                25_300.00,
                23_900.00,
                19_600.00,
                23_060.00,
                21_500.00
        		};
        //--------------------------------------------------------------------------
        // Do not change anything else in main other than to uncomment the lines as
        // you complete the method.
        // -------------------------------------------------------------------------
        int monthsForReport = NUM_MONTHS;
        int monthsBonusMade = -1;
        int monthsTargetMissed = -1;
        int greatestBonusMonth = -1;
        int highestMonthMonth = -1;
        int lowestMonthMonth = -1;
        double totalSales = -1;
        double averageSales = -1.0;
        double averageBonusSales = -1.0;
        double totalBonus = -1.0;
        double totalBonusSales = -1.0;
        double averageBonus = -1.0;
        int longestBonusStreak = -1;
        char[] evaluationStats = { 'U', 'n', 'i', 'm', 'p', 'l', 'e', 'm', 'e', 'n', 't', 'e', 'd', '.' };
        double[] targetSales = loadArrays(testTargetSales);
        double[] actualSales = loadArrays(testActualSales);

        
        //-----------------------------------------------------------
        // UNCOMMENT THESE LINES AS YOU IMPLEMENT EACH METHOD
        //-----------------------------------------------------------
    monthsBonusMade = countMonthsBonusMade(targetSales, actualSales, monthsForReport);
    monthsTargetMissed = countMonthsTargetMissed(targetSales, actualSales, monthsForReport);
    totalSales = calculateTotalSales(actualSales, monthsForReport); 
    totalBonusSales = calculateTotalBonusSales(targetSales, actualSales, monthsForReport); 
    totalBonus = calculateTotalBonusPay(targetSales, actualSales, monthsForReport); 
    averageSales = calculateAverageSales(actualSales, monthsForReport); 
    averageBonusSales = calculateAverageBonusSales(targetSales, actualSales, monthsForReport); 
    greatestBonusMonth = findLargestBonusMonth(targetSales, actualSales, monthsForReport);
    highestMonthMonth = findHighestSalesMonth(actualSales, monthsForReport);
    lowestMonthMonth = findLowestSalesMonth(actualSales, monthsForReport);
    longestBonusStreak = getLongestBonusStreak(targetSales, actualSales, monthsForReport); 
    evaluationStats = getEvaluationStats(targetSales, actualSales, monthsForReport);       
        printValues(targetSales, actualSales, monthsForReport);
        printEmployeeStats(targetSales, actualSales, highestMonthMonth, lowestMonthMonth, greatestBonusMonth); 
        printYearlyStats(monthsForReport, totalSales, averageSales, totalBonusSales, totalBonus, averageBonusSales, longestBonusStreak, monthsBonusMade, monthsTargetMissed);
        printPerformanceStats(evaluationStats);
    }

    //--------------------------------------------------------------------------
    // Do not change any of the following methods.
    // -------------------------------------------------------------------------
    private static void printValues(double[] target, double[] actual, int numMonths)
    {
        System.out.printf("%6s%10s%10s%10s%10s%n", "Month", "Target", "Actual", "Diff", "Bonus");
        String fmt = "%6d%10.2f%10.2f%10.2f%10.2f%n";
        for (int i=0; i < numMonths; i++)
        {
            double potentialBonusSales = actual[i] - target[i];
            double bonus = (potentialBonusSales > 0 ? potentialBonusSales : 0) * BONUS_COMMISSION;
            System.out.printf(fmt, i+1, target[i], actual[i], potentialBonusSales, bonus);
        }
    }
    
    private static double[] loadArrays(double[] source) {
        double[] target = new double[2*source.length];
        for (int i = 0; i < source.length; i++) {
            target[i] = source[i];
        }
        return target;
    }
    
    private static void printEmployeeStats(double[] targetSales, double[] actualSales, int bestMonth, int lowestMonth, int bestBonusMonth) 
    {
        System.out.println("--------------------------------------------------");
        System.out.printf("%-20s%5s%10s%n", "", "Month", "Sales");
        if (bestMonth >= 0) 
        {
            System.out.printf("%-20s%5d%10.2f%n", "Best Month:", bestMonth+1, actualSales[bestMonth]);
        } 
        else 
        {
            System.out.println("Best Month --- unimplemented");
        }
        if (lowestMonth >= 0) 
        {
            System.out.printf("%-20s%5d%10.2f%n", "Worst Month:", lowestMonth+1, actualSales[lowestMonth]);
        } 
        else
        {
            System.out.println("Lowest month --- unimplemented");
        }
        if (bestBonusMonth >= 0) 
        {
            System.out.printf("%-20s%5d%10.2f%n", "Largest Bonus Sales:", bestBonusMonth+1, actualSales[bestBonusMonth] -
                targetSales[bestBonusMonth]);
        } 
        else
        {
            System.out.println("Highest Bonus Month --- No bonus month or unimplemented");
        }
        System.out.println("--------------------------------------------------");
    }
    
        private static void printYearlyStats(int totalMonths, double totalSales, double averageSale,
                double totalBonusSales, double totalBonus, double averageBonusSales, int longestStreak,
                int monthsBonusMade, int monthsTargetMissed) 
        {
            System.out.printf("%-25s%10.2f%n", "Total Sales:", totalSales);
            System.out.printf("%-25s%10.2f%n", "Average Sale:", averageSale);
            System.out.printf("%-25s%10.2f%n", "Total Bonus Sales:", totalBonusSales);
            System.out.printf("%-25s%10.2f%n", "Average Bonus Sales:", averageBonusSales);
            System.out.printf("%-24s$%10.2f%n", "Total Bonus:", totalBonus);
            System.out.printf("%-24s$%10.2f%n%n", "Average Bonus:", totalBonus/totalMonths);
            System.out.printf("%-25s%7d%n", "Months Target Made:", totalMonths - monthsTargetMissed);
            System.out.printf("%-25s%7d%n", "Months Target Missed:", monthsTargetMissed);
            System.out.printf("%-25s%7d%n", "Months Bonus Made:", monthsBonusMade);
            System.out.printf("%-25s%7d%n", "Longest Bonus Streak:", longestStreak);
            
        }
    
    private static void printPerformanceStats(char[] record)
    {
        System.out.printf("%s: ", "Performance Summary");
        for (int i=0; i < record.length; i++) 
        {
            System.out.printf("%c", record[i]);
        }
        System.out.println();
    }
    //--------------------------------------------------------------------------------------------
    // Do not modify any code above this line except as specified in the comments above.
    //--------------------------------------------------------------------------------------------


    //--------------------------------------------------------------------------------------------
    // Your code goes here
    //--------------------------------------------------------------------------------------------
    //countMonthsBonusMade method
    private static int countMonthsBonusMade(double[] targetSales, double [] actualSales, int monthsForReport )
    {
    	int count = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		if (actualSales[i] > targetSales[i])
    		{
    			count++;
    		}
    	}
    	return count;
    }
    //countMonthsTargetMissed method
    private static int countMonthsTargetMissed(double[] targetSales, double[] actualSales, int monthsForReport)
    {
    int count = 0;
    for (int i = 0; i < monthsForReport; i++)
    	{
    	if (actualSales[i] < targetSales[i])
    		{
    		count++;
    		}
    	}
    	return count;
    }
   //calculateTotalSales method 
    private static double calculateTotalSales(double[] actualSales, int monthsForReport)
    {
    	double total = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		total += actualSales[i];
    	}
    	return total;
    }
    //calculateTotalBonusSales method 
    private static double calculateTotalBonusSales(double[] targetSales, double[] actualSales, int monthsForReport)
    {
    	double totalBonusSales = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		if (actualSales[i] > targetSales[i])
    		{
    			totalBonusSales += (actualSales[i] - targetSales[i]);
    		}
    	}
    	return totalBonusSales;
    }
    //calculateTotalBonusPay method
    private static double calculateTotalBonusPay(double[] targetSales, double[]actualSales, int monthsForReport)
    {
    	return calculateTotalBonusSales(targetSales, actualSales, monthsForReport) * BONUS_COMMISSION;
    }
    //calculateAverageSales method
     private static double calculateAverageSales(double[] actualSales, int monthsForReport)
    {
    	return calculateTotalSales(actualSales, monthsForReport) / monthsForReport;
    }
    //calculateAverageBonus method 
    private static double calculateAverageBonusSales(double[] targetSales, double[] actualSales, int monthsForReport)
    {
    	return calculateTotalBonusSales(targetSales, actualSales, monthsForReport) / monthsForReport;
    }
    //findLargestBonusMonth method
    private static int findLargestBonusMonth(double[] targetSales, double[]actualSales, int monthsForReport)
    {
    	int maxIndex = 0;
    	double maxBonus = 0;
    	for (int i = 0; i < monthsForReport; i++)
    		{
    			double bonus = actualSales[i] - targetSales[i];
    			if (bonus > maxBonus)
    			{
    				maxBonus = bonus;
    				maxIndex = i;
    			}
    		}
    		return maxIndex;
    	}
    //findHighestSalesMonth method 
    private static int findHighestSalesMonth(double[] actualSales, int monthsForReport)
    {
    	int maxIndex = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		if (actualSales[i] > actualSales[maxIndex])
    		{
    			maxIndex = i;
    		}
    	}
    	return maxIndex;
    }
    //findLowestSalesMonth method
    private static int findLowestSalesMonth(double[] actualSales, int monthsForReport)
    {
    	int minIndex = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		if (actualSales[i] < actualSales[minIndex])
    		{
    			minIndex = i;
    		}
    	}
    	return minIndex;
    }
    //gretLongestBonusStreak method
    private static int getLongestBonusStreak(double[] actualSales, double[] targetSales, int monthsForReport)
    {
    	int longestStreak = 0;
    	int currentStreak = 0;
    	for (int i = 0; i < monthsForReport; i++)
    	{
    		if (actualSales[i] > targetSales[i])
    		{
    			currentStreak++;
    			if (currentStreak > longestStreak)
    			{
    				longestStreak = currentStreak;
    			}
    		} 
    		else 
    		{
    			currentStreak = 0;
    		}
    	}
    	return longestStreak +1;
    }
    //getEvaluationStats method 
    private static char[] getEvaluationStats(double[] targetSales, double[] actualSales, int monthsForReport)
    {
        char[] stats = new char[monthsForReport];
        for (int i = 0; i < monthsForReport; i++)
        {
        	double diff = actualSales[i] - targetSales[i];
        	if (diff > 0)
        	{
        		stats[i] = BONUS_MONTH;
        	}
        	else if (diff >= -SATISFACTORY_LIMIT)
        	{
        		stats[i] = SATISFACTORY_MONTH;
        	}
        	else if (diff >= -DEFICIENT_LIMIT)
        	{
        		stats[i] = DEFICIENT_MONTH;
        	}
        	else 
        	{
        		stats[i] = UNSATISFACTORY_MONTH;
        	}
        }
        return stats;
    }

    //--------------------------------------------------------------------------------------------
    // End of your code
    //--------------------------------------------------------------------------------------------
}

