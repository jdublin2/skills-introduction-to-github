//AUTHOR: James Dublin II
//COURSE: CPT 167
//PURPOSE: Calculate cost of paint 
//STARTDATE: 1/21/2025
package edu.tridenttech.cpt167.dublin.program1;
//SCANNER OPEN
import java.util.Scanner;

public class PaintSquares {
	
	public static void main(String[] args) {
//DECLARATIONS		
	final double PRICE_PER_PINT = 9.75;
	String colorIn; 
	String colorOut; 
	double lengthIn;
	double lengthOut;
	double areaIn;
	double areaOut;
	double paintIn;
	double paintOut;
	double costIn;
	double costOut;
	double totalPaint;
	double totalCost;
//SCANNER STATEMENT
	Scanner console = new Scanner(System.in);
//WELCOME
	System.out.println("Welcome to the Paint Cost Calculator");
	
//INPUTS
	System.out.println("What color is the larger sqaure?");
	colorOut = console.nextLine();
	System.out.println("What color is the smaller square?");
	colorIn = console.nextLine();
	System.out.println("What is the length of the sides of the larger square?");
	lengthOut = console.nextDouble();
	System.out.println("What is the length of the sides of the smaller square?");
	lengthIn = console.nextDouble();
	
//PROCESS
	areaOut = lengthOut * lengthOut;
	areaIn = lengthIn * lengthIn;
	paintIn = areaIn / 20;
	paintOut = (areaOut - areaIn) / 20;
	costIn = paintIn * PRICE_PER_PINT;
	costOut = paintOut * PRICE_PER_PINT;
	totalPaint = paintIn + paintOut;
	totalCost = costIn + costOut;
	
//OUTPUTS
	System.out.println("The total area of the larger square is " + areaOut + ".");
	System.out.println("The total area of the smaller square is " + areaIn + ".");
	System.out.println("You wil need " + paintOut + " pints of " + colorOut + " paint.");
	System.out.println("This will cost $" + costOut + ".");
	System.out.println("You will need " + paintIn + " pints of " + colorIn + " paint.");
	System.out.println("This will cost $" + costIn + ".");
	System.out.println("The total pints of paint needed will be " + totalPaint + ".");
	System.out.println("The total cost of all paint will be $" + totalCost + ".");
	
//Farewell
	System.out.println("Thank you for using the Paint Cost Calculator; have a nice day!");
//SCANNER CLOSE
	console.close();
}	
	}