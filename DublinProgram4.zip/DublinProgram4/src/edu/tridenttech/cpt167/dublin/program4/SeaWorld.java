//AUTHOR: JAMES DUBLIN II 
//COURSE: CPT 167
//PURPOSE: MANAGE SEAWORLD TICKETS
//STARTDATE: 2-11-25
package edu.tridenttech.cpt167.dublin.program4;

import java.util.Scanner;

public class SeaWorld {
		// Moved final variables 
	 	public static final String TICKET_ADULT = "Adult";
	 	public static final String TICKET_JUNIOR = "Junior";
	 	public static final String TICKET_TODDLER = "Toddler";
	 	public static final String MENU_QUIT = "Quit";
	 	public static final char ADULT_SELECTION = 'A';
	 	public static final char JUNIOR_SELECTION = 'J';
	 	public static final char TODDLER_SELECTION = 'T';
	 	public static final char QUIT_SELECTION = 'Q';
	 	public static final double ADULT_PRICE = 14.50;
	 	public static final double JUNIOR_PRICE = 9.50;
	 	public static final double TODDLER_PRICE = 0.00;
	 	
	 	//displayWelcome Method
	public static void displayWelcome()
	{
		System.out.println("Welcome to Summerville Sea World!"); 
	}
	 	
	 	//displayMainMenu Method 
	public static void displayMainMenu()
	{
		System.out.println();
        System.out.println("Ticket Menu:");
        System.out.printf("%s) %-10s%6.2f\n", ADULT_SELECTION, TICKET_ADULT, ADULT_PRICE);
        System.out.printf("%s) %-10s%6.2f\n", JUNIOR_SELECTION, TICKET_JUNIOR, JUNIOR_PRICE);
        System.out.printf("%s) %-10s%6.2f\n", TODDLER_SELECTION, TICKET_TODDLER, TODDLER_PRICE);
        System.out.printf("%s) %-10s\n", QUIT_SELECTION, MENU_QUIT);
        System.out.println("Please make your selection:");
	}
	
		//getValidatedTicketSelection Method 
	public static char getValidatedTicketSelection(Scanner input)
	{
		char selection;
		//PRIME READ
		selection = input.next().toUpperCase().charAt(0);
		   while (selection != ADULT_SELECTION && selection != JUNIOR_SELECTION && selection != TODDLER_SELECTION && selection != QUIT_SELECTION)
		   { //ERROR MESSAGE
	            System.out.println("Invalid selection.\n");
	            displayMainMenu();
	            selection = input.next().toUpperCase().charAt(0);
		   }//END OF validation loop - for ticket menu
		return selection;
	}
	
		//getValidatedTicketCount Method 
	public static int getValidatedTicketCount(Scanner input)
	{
		int selection;
		System.out.println("How may tickets would you like to purchase?");
        selection = input.nextInt();
        while (selection <= 0 || selection > 10) 
         {
             System.out.println("Invalid entry");
             System.out.println("Please enter the desired number of tickets.");
             selection = input.nextInt();
         } 
        return selection;
	}
		//displaySinglePurchase Method 
	public static void displaySinglePurchase(String ticketSelection, int ticketAmount, double ticketPrice, double purchaseTotal)
	{
		System.out.println("");
		System.out.println("Thank you for your purchase.");
		System.out.println("");
        System.out.println("Purchase Report:");
        System.out.printf("%-13s%-8s\n", "Ticket Type:", ticketSelection); 
        System.out.printf("%-13s%8d\n", "Sold:", ticketAmount); 
        System.out.printf("%-13s%8.2f\n", "Unit Price:", ticketPrice);
        System.out.printf("%-13s%8.2f\n", "Total:", purchaseTotal);
	}
		//displayFinalReport Method 
	public static void displayFinalReport(int purchaseCount, int totalAdultTickets, int totalJuniorTickets, int totalToddlerTickets, double totalAdultSales, double totalJuniorSales, double totalToddlerSales)
	{
		if (purchaseCount > 0)
		{
		int totalTicketsSold = totalAdultTickets + totalJuniorTickets + totalToddlerTickets;
		double totalRevenue = totalAdultSales + totalJuniorSales + totalToddlerSales;
		System.out.println("");
		System.out.println("PORPOISE TICKET SALES REPORT");
		System.out.println("");
		System.out.println("Total Purchases: " + purchaseCount);
		System.out.println("");
		System.out.println("Tickets Purchased:");
		System.out.println("");
		System.out.printf("%-9s%-9s%-6s", "Type", "Sold", "Value");
		System.out.println("");
		System.out.println("");
		System.out.printf("%-12s%-7d%-6.2f", TICKET_TODDLER, totalToddlerTickets, totalToddlerSales);
		System.out.println("");
		System.out.println("");
		System.out.printf("%-12s%-7d%-6.2f", TICKET_JUNIOR, totalJuniorTickets, totalJuniorSales);
		System.out.println("");
		System.out.println("");
		System.out.printf("%-12s%-7d%-6.2f", TICKET_ADULT, totalAdultTickets, totalAdultSales);
		System.out.println("");
		System.out.println("");
		System.out.println("=========================");
		System.out.println("");
		System.out.println("");
		System.out.printf("%-12s%-7d%-6.2f", "Total", totalTicketsSold, totalRevenue);
		System.out.println("");
		}
	}
	
	//MAIN METHOD
    public static void main(String[] args) {
        // Declare variables
        Scanner input = new Scanner(System.in);

        char menuSelection = ' '; 
        String ticketSelection = " ";
        int ticketAmount = 0;
        int purchaseCount = 0;
        int totalAdultTickets = 0;
        int totalJuniorTickets = 0;
        int totalToddlerTickets = 0;
        double totalAdultSales = 0;
        double totalJuniorSales= 0; 
        double totalToddlerSales = 0;
        double purchaseTotal = 0.00;
        double ticketPrice = 0.00;
        

        // Welcome user
        displayWelcome();
        
        // INITIALIZE LCV (menuSelection)
        // Display menu
        displayMainMenu();
        //VALIDATE SELECTION
        menuSelection = getValidatedTicketSelection(input);
        
        while (menuSelection != QUIT_SELECTION) 
        {
            // Request ticket count
        	ticketAmount = getValidatedTicketCount(input);
        	
            if (menuSelection == ADULT_SELECTION) 
            {
                ticketSelection = TICKET_ADULT;
                ticketPrice = ADULT_PRICE;
                totalAdultTickets += ticketAmount;
                totalAdultSales += ticketAmount * ticketPrice;
            } 
            else if (menuSelection == JUNIOR_SELECTION) 
            {
                ticketSelection = TICKET_JUNIOR;
                ticketPrice = JUNIOR_PRICE;
                totalJuniorTickets += ticketAmount;
                totalJuniorSales += ticketAmount * ticketPrice;
            } else 
            {
                ticketSelection = TICKET_TODDLER;
                ticketPrice = TODDLER_PRICE;
                totalToddlerTickets += ticketAmount;
                totalToddlerSales += ticketAmount * ticketPrice;
            }
            //COUNTER & PROCESS
            purchaseCount++;
            purchaseTotal = ticketAmount * ticketPrice;
            
            
            // Display purchase report
           displaySinglePurchase(ticketSelection, ticketAmount, ticketPrice, purchaseTotal);

            // UPDATE LCV (menuSelection)
            // Display menu
            displayMainMenu();
            //VALIDATE SELECTION
            menuSelection = getValidatedTicketSelection(input);
        }
            // Display final report if ticket purchased
        	displayFinalReport(purchaseCount, totalAdultTickets, totalJuniorTickets, totalToddlerTickets, totalAdultSales, totalJuniorSales, totalToddlerSales);
            System.out.println("");
            System.out.println("Thank you for visiting Summerville Sea World!");
            input.close();

        
    }
}