package edu.tridenttech.cpt167.dublin.program5;

import java.util.Scanner;

public class PasswordValidator 
{
		//FINAL VARIABLES
			public static final String TOO_SHORT = "- Password must be at least 8 characters long.";
			public static final String MISSING_UPPER_OR_LOWER = "- Password must contain a mix of uppercase and lowercase letters.";
			public static final String NO_NUMERIC_DIGIT = "- Password must include at least one numeric digit.";
			public static final String MISSING_SPECIAL_CHARACTER = "- Password must contain at least one special character or two numeric digits.";
			public static final String QUIT_STRING = "quit";
			
		//hasValidLength Method
		public static boolean hasValidLength(String password)
		{
			if (password == null || password.length() < 8)
			{
				System.out.print(TOO_SHORT);
				return false;
			}
					return true;
		}
			

	
		//hasMixedCase Method
		public static boolean hasMixedCase(String password)
		{
			if (password == null)
			{
				System.out.print(MISSING_UPPER_OR_LOWER);
				return false;
			}
			boolean hasUpper = false;
			boolean hasLower = false;
			
			for (int i = 0; i < password.length(); i++)
			{
				char ch = password.charAt(i);
				
				if (Character.isUpperCase(ch))
				{
					hasUpper = true;
				}
				else if (Character.isLowerCase(ch))
				{
					hasLower = true;
				}
				if (hasUpper && hasLower) 
				{
					return true;
				}
			}
		System.out.print(MISSING_UPPER_OR_LOWER);
		return false;
		}
		
		//hasDigit Method
		public static boolean hasDigit(String password)
		{
			for (int i = 0; i < password.length(); i++)
			{
				char ch = password.charAt(i);
				
				if (Character.isDigit(ch))
				{
					return true;
				}
			}
			System.out.print(NO_NUMERIC_DIGIT);
			return false;
		}
		//hasSpecialCharacterOrTwoDigits Method 
		public static boolean hasSpecialCharacterOrTwoDigits(String password)
		{
			if (password == null)
			{
			 System.out.print(MISSING_SPECIAL_CHARACTER);
			 return false;
			}
			
			int digitCount = 0;
			boolean hasSpecial = false;
			char[] allowedSpecials = {'!','@','#','$','%','*','.'};
			
			for (int i = 0; i < password.length(); i++)
			{
				char ch = password.charAt(i);
				
				if (Character.isDigit(ch))
				{
					digitCount++;
				}
				else 
			{
				for (int j = 0; j < allowedSpecials.length; j++) 
				{
					if (ch == allowedSpecials[j])
					{
						hasSpecial = true;
					}
				}
	
			}
				if (hasSpecial || digitCount >= 2)
				{
					return true;
				}
			}
			System.out.print(MISSING_SPECIAL_CHARACTER);
			return false;
		}

		//MAIN METHOD
    public static void main(String[] args)
    {
    	//SCANNER INPUT
    	  Scanner scanner = new Scanner(System.in);
    	  
    	System.out.println("Welcome to the Password Validator!\nPassword must be 8 characters long, contain a mix of upper and lowercase letters,\ninclude at least one numeric digit and have one special character or a second digit.");
    	System.out.println("Enter your username:");
    	String username = scanner.nextLine();
    	
    	System.out.println("Enter your password: \nOr Enter: quit to exit.");
        String password = scanner.nextLine();
        
        while (!password.equalsIgnoreCase(QUIT_STRING))
        {
        	//VALIDATE LENGTH
        	hasValidLength(password);
        	//VALIDATE MIX CASE 
        	hasMixedCase(password);
        	//VALIDATE DIGIT
        	hasDigit(password);
        	//VALIDATE SPECIAL CHARACTER OR SECOND DIGIT
        	hasSpecialCharacterOrTwoDigits(password);
        	
        	//DISPLAY OUTPUT
        	if (hasValidLength(password) && hasMixedCase(password) && hasDigit(password) && hasSpecialCharacterOrTwoDigits(password))
        	{
        	System.out.println("\nPassword: " + password + " Is valid!");
        	}
        
        	//REPROMPT FOR VALID INPUT
        	System.out.println("");
			System.out.println("Enter your password: \nOr Enter: quit to exit.");
			password = scanner.nextLine();
        }
        //DISPLAY FAREWELL 
        System.out.println("Bye " + username + " Thanks for using Password Validator!");
        scanner.close();
    }
}