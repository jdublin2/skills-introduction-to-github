//AUTHOR: JAMES DUBLIN II
//CPT 167
//PURPOSE: MENU SELECTION
//STARTDATE: 1/28/2025
package edu.tridenttech.cpt167.dublin.program2;
//SCANNER OPEN
import java.util.Scanner; 

public class QuiltShop {

	public static void main(String[] args) {

//DECLARATIONS
		String userName;
		String fabric = null;
		final String fabric_A = "Floral";
		final String fabric_B = "Solid";
		final String fabric_C = "Geometric";
		final String quit = "Quit";
		double fabricPrice = 0;
		final double price_A = 4.99;
		final double price_B = 5.49; 
		final double price_C = 9.99; 
		final char selection_A = 'A';
		final char selection_B = 'B';
		final char selection_C = 'C';
		final char selection_D = 'D';
		final double localTax = .075;
		char selection ;
		double yards =0;
		double cost =0;
		double subtotal=0;
		double totalCost;
		double discount =0; 
		double tax =0;
		
		
		
//SCANNER STATEMENT 
Scanner console = new Scanner(System.in); 
		 
//WELCOME
System.out.println("Welome to Quincy's; may I ask your name?"); 
userName = console.nextLine();

//INPUTS-MENU
System.out.println("Fabric Menu:");
System.out.printf("%1s) %-20s $%.2f\n" , selection_A, fabric_A, price_A);
System.out.printf("%1s) %-20s $%.2f\n" , selection_B, fabric_B, price_B);
System.out.printf("%1s) %-20s $%.2f\n" , selection_C, fabric_C, price_C);
System.out.printf("%1s) %-20s" , selection_D, quit);
System.out.println("");
System.out.println("Please make a selection:");
selection = console.nextLine().toUpperCase().charAt(0);

//SELECTION DECISION
if (selection == selection_A)
{
		fabric = fabric_A;
		fabricPrice = price_A;
//YARDS INPUT
		System.out.println("How many yards would you like?");
		yards = console.nextDouble();
//PROCESS
				cost = fabricPrice * yards;
//DISCOUNT DECISION		
		if (cost>= 50 && cost<= 99.99)
		{
			discount = 5;
		}
		else if (cost>= 100 && cost<= 199.99)
		{
			discount = 15;
		}
		else if (cost>= 200)
		{
			discount = .1 * cost;
		}
		else
		{
			discount = 0;
		}
//PROCESS
		subtotal = cost - discount;
		tax = subtotal * localTax;
		totalCost = subtotal + tax; 
//OUTPUT
		System.out.println("Summary");
		System.out.printf("%-20s %5s\n" , "Fabric:", fabric); 
		System.out.printf("%-20s %5.2f\n" , "Yards:", yards);
		System.out.printf("%-20s %5.2f\n" , "Price/Yard:", fabricPrice);
		System.out.printf("%-20s $%5.2f\n" , "Price:", cost);
		System.out.printf("%-20s $%5.2f\n" , "Discount:", discount);
		System.out.printf("%-20s $%5.2f\n" , "Subtotal:", subtotal);
		System.out.printf("%-20s $%5.2f\n" , "Tax:", tax);
		System.out.printf("%-20s $%5.2f\n" , "Total:", totalCost);
	}

else if (selection == selection_B)
{
		fabric = fabric_B;
		fabricPrice = price_B;
//YARDS INPUT
		System.out.println("How many yards would you like?");
		yards = console.nextDouble();
//PROCESS
				cost = fabricPrice * yards;
//DISCOUNT DECISION		
		if (cost>= 50 && cost<= 99.99)
		{
			discount = 5;
		}
		else if (cost>= 100 && cost<= 199.99)
		{
			discount = 15;
		}
		else if (cost>= 200)
		{
			discount =.1 * cost;
		}
		else
		{
			discount = 0;
		}
//PROCESS
		subtotal = cost - discount;
		tax = subtotal * localTax;
		totalCost = subtotal + tax; 
//OUTPUT
		System.out.println("Summary");
		System.out.printf("%-20s %5s\n" , "Fabric:", fabric); 
		System.out.printf("%-20s %5.2f\n" , "Yards:", yards);
		System.out.printf("%-20s %5.2f\n" , "Price/Yard:", fabricPrice);
		System.out.printf("%-20s $%5.2f\n" , "Price:", cost);
		System.out.printf("%-20s $%5.2f\n" , "Discount:", discount);
		System.out.printf("%-20s $%5.2f\n" , "Subtotal:", subtotal);
		System.out.printf("%-20s $%5.2f\n" , "Tax:", tax);
		System.out.printf("%-20s $%5.2f\n" , "Total:", totalCost);
}
else if (selection == selection_C)
{
		fabric = fabric_C;
		fabricPrice = price_C;
//YARDS INPUT
		System.out.println("How many yards would you like?");
		yards = console.nextDouble();
//PROCESS
				cost = fabricPrice * yards;
//DISCOUNT DECISION		
		if (cost>= 50 && cost<= 99.99)
		{
			discount = 5;
		}
		else if (cost>= 100 && cost<= 199.99)
		{
			discount = 15;
		}
		else if (cost>= 200)
		{
			discount = .1 * cost;
		}
		else
		{
			discount = 0;
		}
//PROCESS
		subtotal = cost - discount;
		tax = subtotal * localTax;
		totalCost = subtotal + tax; 
//OUTPUT
		System.out.println("Summary");
		System.out.printf("%-20s %5s\n" , "Fabric:", fabric); 
		System.out.printf("%-20s %5.2f\n" , "Yards:", yards);
		System.out.printf("%-20s %5.2f\n" , "Price/Yard:", fabricPrice);
		System.out.printf("%-20s $%5.2f\n" , "Price:", cost);
		System.out.printf("%-20s $%5.2f\n" , "Discount:", discount);
		System.out.printf("%-20s $%5.2f\n" , "Subtotal:", subtotal);
		System.out.printf("%-20s $%5.2f\n" , "Tax:", tax);
		System.out.printf("%-20s $%5.2f\n" , "Total:", totalCost);
}
else 
{
	selection = selection_D;
}
//FAREWELL
	System.out.println(userName + " thanks for shopping at Quincy's!");





	}

}
